var indexSectionsWithContent =
{
  0: "abcefgijklmoprstu",
  1: "acglrs",
  2: "r",
  3: "abcefgijklmoprstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

