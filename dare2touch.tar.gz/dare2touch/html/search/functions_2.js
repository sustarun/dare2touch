var searchData=
[
  ['clear_5fboard',['clear_board',['../classGrid.html#aad6bf1f39d476c2792191becfff6ae7f',1,'Grid']]],
  ['client_5fadd_5fplayer',['client_add_player',['../classgc.html#a3401aa6debf5b336a48a5a42c1f30481',1,'gc']]],
  ['client_5fcount_5fdisplay',['client_count_display',['../classgc.html#ae659026a21cfd64c778c63acc9edab57',1,'gc::client_count_display()'],['../classai__gc.html#ae659026a21cfd64c778c63acc9edab57',1,'ai_gc::client_count_display()']]],
  ['client_5fhandle_5finput',['client_handle_input',['../classgc.html#a14953ed5bcb35bccc1b324babdba46e3',1,'gc::client_handle_input()'],['../classai__gc.html#a14953ed5bcb35bccc1b324babdba46e3',1,'ai_gc::client_handle_input()']]],
  ['client_5fkill_5fplayer',['client_kill_player',['../classgc.html#acf09d0cd9b83da0ce0c0b42ff9d1c3c0',1,'gc']]],
  ['client_5fonconnected',['client_onconnected',['../classgc.html#a642a4e4bb060406da36d5b0204f34455',1,'gc']]],
  ['config_5fconnection',['config_connection',['../classgc.html#adde0669179eb5c38217f89e60c1b6aca',1,'gc']]]
];
