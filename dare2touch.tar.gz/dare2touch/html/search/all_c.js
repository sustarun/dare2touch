var searchData=
[
  ['play_5fwith_5ffriends',['Play_With_Friends',['../classclient.html#a94ee480a631cd7f41584ac82cab6e511',1,'client']]],
  ['print_5fgrid',['print_grid',['../classGrid.html#a12c901979ba4f6fed9ab7acf6446f855',1,'Grid']]]
];
