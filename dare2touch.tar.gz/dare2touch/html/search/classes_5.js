var searchData=
[
  ['server',['server',['../classserver.html',1,'']]],
  ['single_5fplayer',['single_player',['../classsingle__player.html',1,'']]]
];
