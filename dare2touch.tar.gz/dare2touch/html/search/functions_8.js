var searchData=
[
  ['kallar',['kallar',['../classgc.html#ad1256b240f829c43b950a61a7de03f96',1,'gc::kallar()'],['../classai__gc.html#ad1256b240f829c43b950a61a7de03f96',1,'ai_gc::kallar()']]],
  ['killed_5fpid_5flist',['killed_pid_list',['../classGrid.html#aa815548b2be05740862b103c7aa21956',1,'Grid']]]
];
