var searchData=
[
  ['random_5fgame_5ffull',['random_game_full',['../classclient.html#a7cd5df357437f92a7c43a9c1a842b10b',1,'client']]],
  ['random_5fplay',['Random_play',['../classclient.html#a8cdbba233cdfe4e70a5636361477dcdf',1,'client']]],
  ['remove_5fplayer',['remove_player',['../classGrid.html#af477b8caba9bddfdad3f122eddee0d32',1,'Grid']]]
];
