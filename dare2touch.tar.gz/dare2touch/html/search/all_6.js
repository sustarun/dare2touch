var searchData=
[
  ['initialize_5fplayers',['initialize_players',['../classGrid.html#a8daddb8056e88aea21c88df8118d4d63',1,'Grid']]],
  ['input_5fdata_5fparser',['input_data_parser',['../classgc.html#abc70eb5e407d31fa0588025c3aa78043',1,'gc::input_data_parser()'],['../classai__gc.html#abc70eb5e407d31fa0588025c3aa78043',1,'ai_gc::input_data_parser()']]]
];
